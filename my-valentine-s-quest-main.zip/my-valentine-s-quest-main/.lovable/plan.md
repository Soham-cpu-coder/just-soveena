
# 💖 Romantic Valentine Proposal Website

## Overview
A bold, passionate digital love letter with dramatic animations, deep reds and rich gradients, and an unforgettable interactive Valentine proposal experience.

---

## Page 1: Our Journey Photo Recap (Full-Screen Intro)
- Full-screen slideshow that plays automatically on page load
- Photos appear one by one with smooth zoom/fade animations
- Each photo has an optional caption with elegant cursive typography
- Deep red/burgundy gradient overlay for cohesion
- After the last photo, a smooth fade transition reveals the main page
- Placeholder images included — clearly marked for easy swapping

## Page 2: Main Valentine Page

### Background
- Auto-rotating background image slideshow with cross-fade transitions (every 5 seconds)
- Dark romantic gradient overlay so text remains readable
- Array of placeholder image URLs, easy to replace

### Background Music
- Romantic background song plays on loop (placeholder audio file)
- Small floating mute/unmute button in the corner (heart-shaped icon)
- Graceful handling of browser autoplay restrictions (tap-to-play fallback)

### The Valentine Question
- Elegant cursive heading with a romantic message
- Large animated question: **"Will you be my Valentine? 💖"**
- Two buttons: **YES** and **NO** with glowing hover effects

### "NO" Button Behavior
- Clicking NO triggers a playful message: **"How dare you 😤💔"** with a shake animation
- The NO button disappears and is replaced by **two YES buttons**
- No way to decline anymore!

### "YES" Button — The Grand Finale
- Full-screen custom image fills the viewport with a dramatic zoom-in
- Custom romantic message displayed in elegant typography
- **Triple celebration effect**: floating hearts rising up + confetti explosion + sparkle particles
- Soft pulsing glow effect on the message
- Background music continues playing
- All text and the image URL clearly marked for customization

## Design & Styling
- **Color palette**: Deep reds, burgundy, dark pinks, gold accents, rich gradients
- **Typography**: Cursive/handwritten fonts (Google Fonts — e.g., "Dancing Script", "Great Vibes")
- **Animations**: Smooth transitions, floating particles, glowing effects throughout
- **Fully responsive**: Works beautifully on mobile and desktop

## Customization
- All images, messages, audio, and captions stored in clearly commented configuration objects at the top of components for easy editing
